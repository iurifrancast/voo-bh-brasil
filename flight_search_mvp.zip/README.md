# ✈️ Flight Search MVP  
Backend básico para busca de passagens com agregação simulada.

## Rodar localmente
```
npm install
npm start
```

Acesse:
```
http://localhost:3000/search
```

## Deploy no Render
- Crie repositório no GitHub
- Conecte no Render > New Web Service
- Start command: `npm start`
- Deploy!
